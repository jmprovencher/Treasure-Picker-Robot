from elements.ElementCartographique import ElementCartographique


class Tresor(ElementCartographique):
    def __init__(self, centre):
        ElementCartographique.__init__(self, centre)



