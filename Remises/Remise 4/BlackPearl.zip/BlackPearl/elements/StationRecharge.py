from elements.ElementCartographique import ElementCartographique


class StationRecharge(ElementCartographique):
    def __init__(self):
        ElementCartographique.__init__(self, (1590, 0))

